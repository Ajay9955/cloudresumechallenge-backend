import json
import boto3

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Visitorcount')
    
    response = table.update_item(
        Key = {'count': 1},
        UpdateExpression = 'ADD VisitCount :inc',
        ExpressionAttributeValues= {':inc' :1},
        ReturnValues = 'UPDATED_NEW'
        )
    return {
        'statusCode': 200,
        'headers':{
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': str(response['Attributes']['VisitCount'])
    }
